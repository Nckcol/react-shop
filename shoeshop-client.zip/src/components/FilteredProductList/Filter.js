import React, { Component } from 'react'

class Filter extends Component {
  render () {
    return (
      <div>Filter</div>
    )
  }
}

export default Filter