import FilteredProductList from './FilteredProductList'

export {
  FilteredProductList
}