import React, { Component } from 'react'

class Pagination extends Component {
  render () {
    return (
      <div>Pagination</div>
    )
  }
}

export default Pagination